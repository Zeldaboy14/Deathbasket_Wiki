'OoT Text Tool' by DeathBasket

1. Information
2. Usage
3. Problems
4. Text commands

Information:
	This tool aims to make text editing easier by taking away
	the need to fiddle around with a hex editor.
	Not compatible with Majora's Mask.

Usage:
	e - extracting text
	This will put every message from the game into a text file
	named 'msg_bank.txt'. The text will also be put into a 
	format that should be more user-friendly than trying to
	edit it in a hex editor. The addresses of the message bank
	and pointer table need to be known, their values for the
	OoT debug ROM will be given in this file.

	i - inserting text
	This will take a text file following the same format as
	was output by the extract function and will convert it
	back to something compatible with Ocarina of Time. An
	option is also given to automatically insert this to a
	ROM.

	OoT debug ROM addresses:
	Pointer table: 0xBC24C0
	Message bank: 0x8C6000

Problems:
	If the message bank is expanded beyond its original size
	then the 'PRESS START' and file select text becomes messed
	up. This is not a fault of the program but of the game
	itself. This can be fixed by changing some values at
	certain addresses in the debug ROM as follows:
	ROMaddr data
	AE60B4: 3C08 bbxx 2508 xxxx
	AE60C4: 3C0F bbyy
	AE60F0: 25EF yyyy
	bbxxxxxx and bbyyyyyy are the addresses of messages FFFC
	and FFFD respectively, these can be found at the end of
	the pointer table (file 'ptr_table' output by the program)
	Note that these numbers are signed so if the lower two bytes
	of the address exceed 0x7FFF then the higher two bytes need
	to be increased by 1, ex. message FFFC has a pointer of
	0x07038400 so go to address 0xAE60B4 in the ROM and write
	3C08 0704 2508 8400.
	I may add a feature to do this automatically in the future.

Text commands:
	<00> - does nothing
	<end> - end of the message
	<03> - does nothing
	<new> - opens a new text box
	<c=x> - changes text colour
	   x:   white
		red
		green
		blue
		cyan
		pink
		yellow
		black
	<sp=x> - prints x spaces
	<msg=x> - jumps to message number x
	<i> - text after this is printed instantly
	</i> - end marker for <i>
	<shop> - used in shop descriptions
	<wait> - text box waits for something to happen?
	<dt=x> - waits for x amount of time before printing
	<in> - waits for input before continuing
	<f=x> - fades the screen for x amount of time
	<link> - prints character name
	<oc> - starts ocarina playing
	<fade> - fades the screen
	<sfx=x> - plays sound effect with id x
	<icon=x> - displays icon number x
	<d=x> - delays printing each letter by x
	<bg=x> - effects how text box displays
	<res1>,<res2>,<res3>,<res4> - result of something
	<spider> - displays number of gold skulltulas
	<noskip> - text cannot be skipped with B
	<ch2> - two choices
	<ch3> - three choices
	<gres=x> - displays result from minigame x
	<time> - displays the current time
	<a> - A button
	<b> - B button
	<c> - C button
	<l> - L button
	<r> - R button
	<z> - Z button
	<up> - up-C
	<down> - down-C
	<left> - left-C
	<right> - right-C
	<da> - down arrow
	<as> - analog stick
	<d> - d-pad

Based on this information:
http://wiki.spinout182.com/w/Zelda_64:_OoT_Text_Control_Code