
              OoT InstEd

- Ocarina of Time instrument set editor -

	by DeathBasket

1. Information
2. Usage
3. User defined instruments
4. Bugs

Information:

	This is a tool I wrote to help me make instrument
	sets to be used when importing music to Ocarina
	of Time. This tool will not work with Majora's
	Mask because the data it uses are valid only for
	the Ocarina of Time debug ROM (as far as I know).

Usage:

	With this program you should also have a copy of
	the instrument data it uses. This is in a folder
	named 'inst'. Moving this folder will cause some
	parts to no longer work, so don't do that.
	Now for using the program itself:


		-- Instrument set related --

	The main form is pretty straightforward; click
	on the instrument you want to change on the right
	hand side and use the menu on the left to choose
	from the supported instruments. The percussion
	menu is self-explanatory. User defined
	instruments will be in the user file in the
	program's directory, more information on that
	later.
	When you are done, you can save your set to a 
	text file if you want to open it again later, or
	save a binary, which can then be imported to the
	ROM via the instrument set inserter in the tools
	menu.

	The inserter form should be easy enough to
	understand. Choose your ROM and instrument set
	binary file and change the location and size of
	Audiobank if you wish, but this will only be
	updated if there was no space for your file in 
	its current location. You need to press enter
	for these changes to take effect.

	The instrument set to sequence mappings is simple
	enough too; load your ROM and then it will 
	display the sequence number on the left and the
	instrument set that sequence uses on the right.
	Click the number you want to change, then enter
	its new value and hit enter. Done.

		-- Sequence related --

	To use the sequence converter, simply load a 
	MIDI sequence (type 1) and hit convert. The
	right hand side will probably show up with a 
	load of errors or unsupported stuff, but that's
	normal because Zelda's format really doesn't
	support a lot of things MIDI does.
	You should now have a few text files (one for
	each MIDI track) which contain the track data. I
	would recommend opening these up and changing
	the instrument numbers as most have probably got
	reset to zero when converting. The best way is 
	to open up InstEd and create a new instrument
	set, then use those instrument numbers.
	You should also have a file named 'control.txt'
	which contains the equivalent of Zelda's
	'sequence header' - information on tempo changes
	and the file names of the different channels 
	that will be used. You can make changes to this
	if you want to ex. add or remove channels.
	To add an introduction part to a sequence (a
	part of the sequence that will not loop when
	the rest of it does), you need to make two MIDI
	files (one for the looping part and one for the
	other), convert them and then copy all the data 
	from one of the control files into the other.
	When you do this, the data for the part you
	don't want to loop must come first, and you
	must change the '.l' preceding the data to '.i'
	so that the program doesn't get confused about
	where to loop from. However, this feature is
	currently not tested at all so I really don't
	know whether or not it's working.
	To use multiple note layers on the same channel,
	copy all the data after the '.t' command and add
	it on to the end of another file.

	To convert from the text format to a Zelda
	sequence file, open up the sequence builder,
	select your control file (control.txt or 
	whatever you renamed it) and press the 
	build sequence button. Choose where and what
	to save your sequence as and then it should
	work.

	To import your sequence, open the sequence
	inserter, load your sequence file and ROM
	file, change the settings if you need to and
	then press insert. As with the instrument set
	inserter, the size and location of Audioseq 
	will only be updated if there is no space for
	your sequence at its current location.

		-- Instrument ripper --

	I haven't put in a way to automatically detect
	the ROM that is loaded so make sure you've 
	selected the right one. Supported ROMs are:
	Ocarina of Time debug ROM
	Majora's Mask (U) (decompressed only!)
	Super Mario 64 (U)
	To use this, simply put in the instrument set
	number and the number of the instrument whose
	data you want to rip.
	Output will be put in a folder named
	'set(xx)inst(yy)'.
	This feature hasn't been tested all that much
	so there may be errors popping up, especially
	with SM64 as I still don't know if it follows
	exactly the same format as Zelda.
	Output from this can be used with the
	instrument set builder by putting it in the
	'user' folder in the program's directory.

		-- Sample inserter --

	Pretty straightforward; load your ROM, load 
	your sample and hit insert. Beware though,
	since this reads file addresses from the file
	table to figure out where/if Audiotable can
	be moved, any maps etc. you have that are not
	pointed to could be overwritten.
	Again, look out for bugs, I really haven't been
	doing much in the way of testing lately.
	

User defined instruments:

	You should only really need to know this if you
	can't get the instrument data using the
	instrument ripper (ex. it is from another game).
	This is a little advanced, but I will try to
	explain it.
	First, you need to get all the data relevant to
	your instrument and lump it into one file, ex.
	instrument_name.i - the extension is important
	because the program looks for it. The 
	instrument's 'index' MUST be the first thing in
	the file or your instrument will not work.
	Now you need a file named 'ptrs.txt' which 
	contains the information needed to update all of
	the pointers in this file. The file must follow
	this format:

	address:pointer
		address gives the location of a pointer
		and pointer is where this should point
		relative to the start of the file.
	p
		sets a flag to change the format 
		on all subsequent lines.

	after 'p' flag has been set:

	addr-addr2.inc
		addr is the address to start at, addr2
		is the address to finish at, and inc
		is the amount to incrememnt the 
		address, the next line must follow the
		format:
	radd:pointer(+pinc)
		raddr is the address relative to addr
		where the pointer to update is, pointer
		is where this should point relative to
		the start of the file and pinc is the 
		amount to increment the pointer, which
		is optional.

	If you need exmaples of how to set these up,
	have a look at some of the included files in
	the instrument folders.

Bugs:

	I don't actually know of any at the present
	time. If samples are not playing back
	correctly it is 99% likely to be a fault with 
	the game; some instrument sets use a base
	address from which to load samples and I did
	not know about this when getting the instrument
	data from them. As far as I know these have all
	been fixed though.
	The sequence converter/builder/inserter really
	have not been tested enough yet so I don't know
	what sorts of trouble they might have.

https://sites.google.com/site/deathbasketslair/zelda/ocarina-of-time/instrument-set-format
https://sites.google.com/site/deathbasketslair/zelda/ocarina-of-time/sequenced-music-format
https://sites.google.com/site/deathbasketslair/programming/ocarina-of-time-instrument-set-editor-oot-insted

http://www.the-gcn.com/topic/1582-oot-insted-instrument-editor/